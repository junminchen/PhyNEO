#!/usr/bin/env python
import numpy as np
import sys



datafile = 'simulation.out'
data = np.loadtxt(datafile)

#data = np.loadtxt(datafile+'simulation_8p.md')
#data = np.loadtxt(datafile+'simulation.md')

step = data.T[0]
t = data.T[1]
# T = data.T[2]
# e = data.T[3]
T = data.T[3]
e = data.T[-1]
rou = data.T[-1]
ave_dens = np.mean(rou[int(len(rou)*3/4):int(len(rou)*4/4)])
std_dens = np.std(rou[int(len(rou)*3/4):int(len(rou)*4/4)])
print(ave_dens, std_dens)
