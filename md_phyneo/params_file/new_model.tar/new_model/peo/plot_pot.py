#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import sys
import scienceplots
plt.style.use(['science','no-latex','nature'])

# column   1     --> step : The current simulation time step.
# column   2     --> time{picosecond} : The elapsed simulation time.
# column   3     --> conserved{kelvin} : The value of the conserved energy quantity per bead.
# column   4     --> temperature{kelvin} : The current temperature, as obtained from the MD kinetic energy.
# column   5     --> potential{kiloj/mol} : The physical system potential energy.
# column   6     --> kinetic_cv{kelvin} : The centroid-virial quantum kinetic energy of the physical system.
# column   7     --> pressure_cv{megapascal} : The quantum estimator for pressure of the physical system.
# column   8     --> volume{angstrom3} : The volume of the cell box.
# column   9     --> density{g/cm3} : The mass density of the physical system.

# datafile = sys.argv[1]
datafile = 'simulation.out'

data = np.loadtxt(datafile)
fig, ax = plt.subplots(1, 1, figsize=(8,4))

step = data.T[0]
t = data.T[1]
# t = data.T[0]
rou = data.T[2]

ave_dens = np.mean(rou[int(len(rou)*3/4):])
std_dens = np.std(rou[int(len(rou)*3/4):])
print('Average Density (cm3/g):', ave_dens)
print('Standard Deviation (cm3/g):', std_dens)
ax.plot(t[10:],rou[10:],label='PhyNEO')
# ax.text(0.98, 0.05, '\nPhyNEO Density = %.4f ± %.4f(kJ/mol)'%(ave_dens,std_dens),
#         verticalalignment='bottom', horizontalalignment='right',
#         transform=ax.transAxes)

# plt.xlim(0,500)
# plt.ylim(0.9,)
plt.xlabel('Time (ps)')
plt.ylabel('Potential (Kelvin)')
plt.tick_params(axis='both', which='both', bottom=True, top=False, left=True, right=False, labelbottom=True, labelleft=True)
plt.legend(loc='best',frameon=False)
plt.savefig('./res_pot.pdf', dpi=300, bbox_inches = 'tight')
plt.tight_layout() 
# plt.show()
