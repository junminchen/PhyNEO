#!/bin/python

import numpy as np 
import sys

kB = 1.38e-23 # J/K  #8.31446261815324 # kJ/mol/K
T = 300 #kelvin
#Hartree_2_kJ_per_mol = 2625.5
nmolecule = 1024
nA = 6.02e23
Hartree_2_J = 4.359748199E-18
per_mol_2_per_g = 1/0.018 * 1e-3
fname = sys.argv[1]
eps_v  = []
eps_v_prime = []

# ifile = open("simulation.out_prev", 'r')
# for line in ifile:
#     words = line.split()
#     if '#' not in words:
#         density = float(words[3])
#         eps_v.append(float(words[4]))
#         eps_v_prime.append(float(words[5]))

ifile = open(fname, 'r')
for line in ifile:
    words = line.split()
    if '#' not in words:
        density = float(words[3])
        eps_v.append(float(words[4]))
        eps_v_prime.append(float(words[5]))
eps_v = np.array(eps_v)[np.arange(0, len(eps_v), 1)]
eps_v_prime = np.array(eps_v_prime)[np.arange(0, len(eps_v_prime), 1)]

def calc_Cv(eps_v, eps_v_prime):
    post_fac = np.average(np.square(eps_v)) - np.average(eps_v)**2 - np.average(eps_v_prime)
    Cv = 1/(kB * T**2) * post_fac * Hartree_2_J ** 2 /nmolecule * nA * per_mol_2_per_g * density 
    return Cv

i_tdependence = False
if len(sys.argv) > 2 and sys.argv[2] == "t":
    i_tdependence = True

if i_tdependence:
    for i in range(4000, eps_v.shape[0]):
        Cv = calc_Cv(eps_v[:i], eps_v_prime[:i])
        t = i/1000
        print(t, Cv)
else: 
    print(calc_Cv(eps_v, eps_v_prime))
    Cv = []
    Nseg = 3
    LEN = int(len(eps_v)/3)
    for i in range(Nseg):
        Cv.append(calc_Cv(eps_v[np.arange(i*LEN, (i+1)*LEN)], eps_v_prime[np.arange(i*LEN, (i+1)*LEN)]))
    Cv = np.array(Cv)
    ave = np.average(Cv)
    print(ave, np.sqrt(np.average((Cv - ave)**2)))

